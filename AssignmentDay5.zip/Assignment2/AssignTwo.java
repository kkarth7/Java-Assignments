package com.te.Assignment2;

import java.util.Scanner;

import com.te.Assignment1.UserMainCodeOne;

public class AssignTwo {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		String s=sc.nextLine();
		System.out.println(UserMainCodeTwo.checkCharacters(s));
	}

}
