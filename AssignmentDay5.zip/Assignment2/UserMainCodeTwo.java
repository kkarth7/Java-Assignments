package com.te.Assignment2;

public class UserMainCodeTwo {

	public static String checkCharacters(String s) {
		// TODO Auto-generated method stub
		
		if(s.charAt(0)==s.charAt(s.length()-1))
		{
			return "valid";
		}
		else
		{
			return "invalid";
		}
	}

}
