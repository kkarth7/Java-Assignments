package com.te.Assignment1;

public class UserMainCodeOne {

	public static String getMiddleChars(String s) {
	
		char c1=s.charAt(s.length()/2-1);
		char c2=s.charAt(s.length()/2);
		String s1="";
		return s1=s1+c1+c2;
		
	
	}

}
	