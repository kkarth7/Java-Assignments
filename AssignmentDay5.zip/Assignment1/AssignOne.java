package com.te.Assignment1;

import java.util.Scanner;

public class AssignOne {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		String s=sc.nextLine();
		System.out.println("final output is: "+UserMainCodeOne.getMiddleChars(s));
		
		
	}

}
