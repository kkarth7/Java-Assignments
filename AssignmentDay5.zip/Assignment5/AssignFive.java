package com.te.Assignment5;

import java.util.Scanner;


public class AssignFive {

	public static void main(String[] args) {

		Scanner scn=new Scanner(System.in);
		System.out.println("enter the size string");
		int size=scn.nextInt();
		System.out.println("enter the color name");
		String[] s=new String[size];
		for (int i = 0; i < s.length; i++) {
			s[i]=scn.next();
			
		}
		System.out.println("enter the color");
		String s1=scn.next();
		int n=UserMainCodeFive.getElementPosition(s,s1);
		System.out.println(n);
	}

}
