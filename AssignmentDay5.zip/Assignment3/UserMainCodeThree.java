package com.te.Assignment3;

public class UserMainCodeThree {

	public static String formNewWord(String s, int n) {
		// TODO Auto-generated method stub
	 String sf=""; String s1="",s2="";
		for (int i = 0; i < n; i++) 
		{
			s1=s1+s.charAt(i);	
		}
		for (int j = s.length()-n; j<s.length(); j++) 
		{
			s2=s2+s.charAt(j);
		}
		sf=s1+s2;
		
		return sf;
	}

}
