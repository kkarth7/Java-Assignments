package com.te.Assignment3;


import java.util.Scanner;

import com.te.Assignment2.UserMainCodeTwo;

public class AssignThree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc= new Scanner(System.in);
		
		String s=sc.nextLine();
		int n=sc.nextInt();
		System.out.println(UserMainCodeThree.formNewWord(s,n));
		
	}

}
