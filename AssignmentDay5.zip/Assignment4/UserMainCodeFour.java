package com.te.Assignment4;

public class UserMainCodeFour {

	public static String removeEvenVowels(String s) {
		// TODO Auto-generated method stub
	
		char chars[]=s.toCharArray();
		s="";
		for (int i = 0; i < chars.length; i++) 
		{
			if (i%2!=0 && (chars[i]=='a'|| chars[i]=='e' || chars[i]=='i' || chars[i]=='o' || chars[i]=='u'))
			{
			
			}
			else
			{
				s=s+chars[i];
			}
		
		}
		return s;	
	}

}
