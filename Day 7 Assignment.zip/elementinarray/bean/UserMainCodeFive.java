package com.te.elementinarray.bean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class UserMainCodeFive {

	public static Integer[] arrayListSubtractor(ArrayList<Integer> list, ArrayList<Integer> list1) {

ArrayList<Integer> list2=new  ArrayList<Integer>();

list2.addAll(list);
list.removeAll(list1);
list1.removeAll(list2);

		ArrayList<Integer> listMerged= new ArrayList<Integer>();
		listMerged.addAll(list);
		listMerged.addAll(list1);
		
		Collections.sort(listMerged);
        Integer[] arr = new Integer[listMerged.size()];

for (int i = 0; i < listMerged.size(); i++) {
	arr[i]=listMerged.get(i);
}		
		return arr;
		
	}
	

}
