package com.te.elementinarray;

import java.util.ArrayList;
import java.util.Scanner;

import com.te.elementinarray.bean.UserMainCodeFive;

public class MainAssignFive {

	public static void main(String[] args) {

		ArrayList<Integer> list=new ArrayList<Integer>();
		ArrayList<Integer> list1=new ArrayList<Integer>();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter size for list one");
		int n1=sc.nextInt();
		for (int i = 0; i < n1; i++) {
			int a=sc.nextInt();
			list.add(a);
		}
		System.out.println("Please enter size for list two");
		int n2=sc.nextInt();
		for (int i = 0; i < n2; i++) {
		int b=sc.nextInt();
		list1.add(b);
		}
		
	Integer[] arrf=UserMainCodeFive.arrayListSubtractor(list,list1);
	
	for (int i = 0; i < arrf.length; i++) {
		System.out.println(arrf[i]);
	}
	
	}
}
