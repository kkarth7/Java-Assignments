package com.te.vowelsarrays;

import java.util.ArrayList;
import java.util.Scanner;

import com.te.vowelsarrays.bean.UserMainCodeTwo;

public class MainAssignTwo {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("siz");
		int n=sc.nextInt();
		sc.nextLine();
		System.out.println("string");
			
		String str[]= new String[n];
		
		for (int i = 0; i < str.length; i++) {
			str[i]=sc.nextLine();
		}
		
		System.out.println(UserMainCodeTwo.matchCharacter(str));
		
	}

}
