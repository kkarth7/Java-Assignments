package com.te.vowelsarrays.bean;

import java.util.ArrayList;

public class UserMainCodeTwo {

	public static ArrayList<String> matchCharacter(String str[]) {
		
		ArrayList<String> charList= new ArrayList();
		
		for (int i = 0; i < str.length; i++) {
			
			if(str[i].charAt(0)=='a' || str[i].charAt(0)=='e'|| str[i].charAt(0)=='i'|| str[i].charAt(0)=='o' || str[i].charAt(0)=='u'&&
					str[i].charAt(str[i].length()-1)=='a' && str[i].charAt(str[i].length()-1)=='e'&& str[i].charAt(str[i].length()-1)=='i'&& str[i].charAt(str[i].length()-1)=='o' && str[i].charAt(str[i].length()-1)=='u')
			{
				charList.add(str[i]);
			}
		}
		
	
		return charList;	
	}

}
