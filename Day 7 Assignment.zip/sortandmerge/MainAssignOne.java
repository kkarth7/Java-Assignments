package com.te.sortandmerge;

import java.util.ArrayList;
import java.util.Scanner;

import com.te.sortandmerge.bean.UserMainCodeOne;

public class MainAssignOne {

	public static void main(String[] args) {

		int listSize=5;
		ArrayList<Integer> list=new ArrayList<Integer>();
		ArrayList<Integer> list1= new ArrayList<Integer>();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter element for two list each 5...");
		
		for (int i = 0; i < listSize; i++) {
			int a=sc.nextInt();
			list.add(a);
		}
		
		for (int i = 0; i < listSize; i++) {
			int b=sc.nextInt();
			list1.add(b);
		}
		
		System.out.println("Final list: "+UserMainCodeOne.sortMergedArrayList(list, list1));
	}

}
