package com.te.sortandmerge.bean;

import java.util.ArrayList;
import java.util.Collections;

public class UserMainCodeOne {

	public static ArrayList<Integer> sortMergedArrayList(ArrayList<Integer> list, ArrayList<Integer> list1) 
	{

		ArrayList<Integer> listMerged= new ArrayList<Integer>(10);
		ArrayList<Integer> listFinal= new ArrayList<Integer>();
		
		listMerged.addAll(list);
		listMerged.addAll(list1);
		
		Collections.sort(listMerged);
		
		System.out.println("List is sorted and merged:"+listMerged);
		int two=listMerged.get(2);
		int six=listMerged.get(6);
		int eight=listMerged.get(8);
		
		listFinal.add(two);
		listFinal.add(six);
		listFinal.add(eight);
		
		return listFinal;
		
	}

}
