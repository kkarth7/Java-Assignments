package com.te.stringarray.bean;

import java.util.ArrayList;
import java.util.Collections;

public class UserMainCodeFour {

	public static String[] convertToStringArray(ArrayList<String> list) {

		Collections.sort(list);
		String str[]=new String[list.size()];
		
		for (int i = 0; i < list.size(); i++) {
			
		 str[i]=list.get(i);
		}
		return str;
		
		
	}

}
