package com.te.stringarray;

import java.util.ArrayList;
import java.util.Scanner;

import com.te.stringarray.bean.UserMainCodeFour;


public class MainAssignFour {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		
		ArrayList<String> list=new ArrayList<String>();
		
		for (int i = 0; i < n+1; i++) {
		
			String input=sc.nextLine();
			list.add(input);
		}
		
		String sf[]=UserMainCodeFour.convertToStringArray(list);
		
		for (int i = 0; i < sf.length; i++) {
			System.out.println(sf[i]);
		}

	
	}

}
