package com.te.removethree.bean;

import java.util.ArrayList;

public class UserMainCodeThree {

	public static ArrayList<Integer> removeMultiplesOfThree(ArrayList<Integer> list,int n) {

		ArrayList<Integer> listMain=new ArrayList();
		
		for (int i = 0; i < list.size(); i++) {
			
			if((i+1)%3!=0)
			{
				listMain.add(list.get(i));
			}
		}
		
		return listMain;
	}

}
