package com.te.removethree;

import java.util.ArrayList;
import java.util.Scanner;

import com.te.removethree.bean.UserMainCodeThree;

public class MainAssignThree {

	public static void main(String[] args) {

		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		
		ArrayList<Integer> list= new ArrayList<Integer>(11);
		
		for (int i = 0; i < n; i++) {
			int a=sc.nextInt();
			list.add(a);
		}
		System.out.println("final output:"+UserMainCodeThree.removeMultiplesOfThree(list,n));
	}

}
