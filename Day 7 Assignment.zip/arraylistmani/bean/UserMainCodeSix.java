package com.te.arraylistmani.bean;

import java.util.ArrayList;
import java.util.Collections;

public class UserMainCodeSix {

	public static ArrayList<Integer> generateOddEvenList(ArrayList<Integer> list, ArrayList<Integer> list1) {
		// TODO Auto-generated method stub
		ArrayList<Integer> listfinl= new ArrayList<Integer>();
		
		for (int i = 0; i < list.size(); i++) {
			
			if(i%2!=0)
			{
				int a=list.get(i);
				listfinl.add(a);
			}
		}
		for (int i = 0; i < list1.size(); i++) {
			
			if(i%2==0)
			{
				int b=list1.get(i);
				listfinl.add(b);
			}
			
		}
		Collections.sort(listfinl);
		
		return listfinl;
	}

}
