package com.te.arraylistmani;

import java.util.ArrayList;
import java.util.Scanner;

import com.te.arraylistmani.bean.UserMainCodeSix;

public class MainAssignSix {

	public static void main(String[] args) {

		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		ArrayList<Integer> list= new ArrayList<Integer>();
		ArrayList<Integer> list1= new  ArrayList<Integer>();
		
		System.out.println("enter first list elements....");
		for (int i = 0; i < n; i++) {
			int a= sc.nextInt();
			list.add(a);
		}
		System.out.println("enter Second list elements....");
		for (int i = 0; i < n; i++) {
			int b= sc.nextInt();
			list1.add(b);
		}
		
		System.out.println(UserMainCodeSix.generateOddEvenList(list,list1));
		
	}

}
