package com.te.day4assign;

import java.util.Arrays;

public class UserMainCodeFour {

	public static int calculateMedian(int[] a) {
int sum=0; int finl=0;
for (int i = 0; i < a.length; i++) {
	Arrays.sort(a); int size=a.length;
	if(size%2==0)
	{
		int med1=size/2; int med=med1-1;
		int sum1=a[med]+a[med+1];
		sum=sum1/2; Math.round(sum);
	System.out.println("sumvalue"+sum);
	}
	
	else 
	{
		int medOdd=a.length/2;
		Math.round(medOdd);
		finl=a[medOdd]; Math.round(finl);
		System.out.println("finl"+finl);
	}
}
if(a.length%2!=0)

	return finl;

return sum;	
	}

}
