package com.te.day4assign;

import java.util.Scanner;

public class AssignSevenDayFour {

	public static void main(String[] args)
	{
		Scanner scn=new Scanner(System.in);
		System.out.println("Enter the Doube Value");
		double num=scn.nextDouble();
		String str=UserMainCodeSeven.checkDigits(num);
		System.out.println(str);

	}
}
