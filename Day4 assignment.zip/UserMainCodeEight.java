package com.te.day4assign;

public class UserMainCodeEight {

	public static int getLargestSpan(int[] a) {
int finl=0;
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				
				if(a[i]==a[j])
					
				{
					finl=a[j];
					
				} 
				break;
			}
		}return finl;
	
	}

}
