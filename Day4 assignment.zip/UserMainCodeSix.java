package com.te.day4assign;

public class UserMainCodeSix {

	public static boolean getPerfection(int a) {
		int temp=a,sum=0;
		int div=a/2;
		for (int i = 1; i <= div; i++) {
			if (a%i==0)
			{
				sum=sum+i;
			}
		}		
		if(sum==temp)
		{
			return true;
		}
		return false;
	}
}
		
		



