package com.te.day4assign;

import java.util.Scanner;

public class AssignSixDayFive {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Please ente the positive number");
		int a=sc.nextInt();
		
		System.out.println("Final output:"+UserMainCodeSix.getPerfection(a));
	}

}
