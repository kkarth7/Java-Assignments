package com.te.day4assign;

public class UserMainCodeThree {

	public static boolean checkTripplets(int[] a) {

		for (int i = 0; i < a.length; i++) {
				
				if(a[i]==a[i+1]&&a[i]==a[i+2])
					
					{
						return true;		
					}
				}
				return false;
	}

}
