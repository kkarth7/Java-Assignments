package com.te.day4assign;

public class UserMainCodeFive {

	public static boolean searchSequence(int[] a) 
	{
		
		for (int i = 0; i < a.length; i++) 
		{
			if(a[i]==1&&a[i+1]==2&&a[i+2]==3)
			{
				return true;
			}
			}
		return false;
		}
	
	}


