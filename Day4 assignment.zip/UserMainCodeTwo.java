package com.te.day4assign;

public class UserMainCodeTwo {

	public static int addAndReverse(int[] a, int startNum) {
		int sum=0;
		
		for (int i = 0; i < a.length; i++) 
		{
			if(a[i]>startNum)		
			{
				sum=sum+a[i];
			}
		}
		return sum;	
	}

}
