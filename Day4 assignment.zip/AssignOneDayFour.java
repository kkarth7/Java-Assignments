package com.te.day4assign;

import java.util.Scanner;

public class AssignOneDayFour {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		int[] arr=new int[5];
		System.out.println("Enter five Elements for array");
		for (int i = 0; i < arr.length; i++) 
		{
			arr[i]=scn.nextInt();
		}
		int[] arr1=UserMainCodeOne.removeTens(arr);
		for (int i = 0; i < arr1.length; i++)
		{
			System.out.println(arr1[i]);
		}
	}

}
