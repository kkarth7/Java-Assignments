package com.te.day4assign;

import java.util.Scanner;

public class AssignFourDayFour {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter the number of elements in array");
		int size=sc.nextInt();
		int a[]=new int[size]; System.out.println("Please enter the element in array");
		for (int i = 0; i < a.length; i++) 
		{
			a[i]= sc.nextInt();
		}
		System.out.println("Final output:"+UserMainCodeFour.calculateMedian(a));
	}

}
