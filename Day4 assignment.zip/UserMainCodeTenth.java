package com.te.day4assign;

import java.util.Arrays;

public class UserMainCodeTenth {
	public static int sumElements(int[] a) {
int j=0,i=0,len=a.length,sum=0,temp[]=new int[a.length];
Arrays.sort(a);

		for (i = 0; i < len-1; i++) {
			if(a[i]!=a[i+1])
			{
				temp[j++]=a[i];
			}
		} 
		temp[j++]=a[len-1];
				a[i]=temp[j];
		for (i = 0; i < j ; i++) {
				if(temp[i]%2==0)
				{
				sum=sum+temp[i];
				}
				if(temp[i]%2!=0)
				{
					return -1;
				}
				}return sum;
		}
	
		
	}
