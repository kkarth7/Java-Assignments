package com.te.pricecalculator;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class MainCodeFourAssignTen {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		System.out.println("Please enter number of devices...");
		int size= sc.nextInt();
		Map<String, Float> map= new HashMap<String, Float>();
		System.out.println("Please enter device name and price one by one...");
		for (int i = 0; i < size; i++) {
			map.put(sc.next(), sc.nextFloat());
		}
		
		float finalResult=UserMainCodeFour.priceCalculator(map);
		
	}

}
