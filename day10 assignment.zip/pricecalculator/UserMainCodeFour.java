package com.te.pricecalculator;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class UserMainCodeFour {

	public static float priceCalculator(Map<String, Float> map) {
		
		System.out.println("Please enter the number of device you want to add...");
		Scanner sc= new Scanner(System.in);
		int addDevice=sc.nextInt(); float sum=0;
		String str[]= new String[addDevice];
		System.out.println("Please enter the device name that you want to add...");
		for (int i = 0; i < addDevice; i++) {
			str[i]=sc.next();
		}
		
		Iterator<String> itr= map.keySet().iterator();
		while(itr.hasNext())
		{
			String key=itr.next();
			for (int j = 0; j < str.length; j++) {
				if(key.equals(str[j]))
				{
					sum=sum+map.get(key);
				}
			}
		}
		System.out.println(sum);
		return 0;
	}

}
