package com.te.leapyear;

import java.util.Scanner;

public class MainCodeTwoAssignTen {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		String s=sc.nextLine();
		
		boolean result= UserMainCodeTwo.isLeapYear(s);
		
		System.out.println(result);
		
	}

}
