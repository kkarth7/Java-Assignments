package com.te.leapyear;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class UserMainCodeTwo {

	public static boolean isLeapYear(String s) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	    LocalDate localDateDob = LocalDate.parse(s,formatter);	

	    return localDateDob.isLeapYear();
	}

}
