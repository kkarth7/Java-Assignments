package com.te.ageofvoting;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class MainCodeOneAssignTen {

	public static void main(String[] args) throws ParseException {

		String dob="16/11/1991";
		String cd="01/01/2015";
		   Period period=UserMainCodeOne.getAge(dob,cd);
	    
	    if(period.getYears()>18)
	    {
	    	System.out.println("You are eligible for voting...");
	    }
	    else
	    {
	    	System.out.println("You are not eligible for voting....");
	    } 
	}

}
