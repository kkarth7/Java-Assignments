package com.te.ageofvoting;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class UserMainCodeOne {
	public static Period getAge(String dob, String cd) 
	{
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    LocalDate localDateDob = LocalDate.parse(dob,formatter);		
    LocalDate localDateCd = LocalDate.parse(cd,formatter);	
    
    Period period = Period.between(localDateDob, localDateCd);  

    System.out.println("Your Age-->"+period.getYears());
    
    return period;
	}
}
