package com.te.stringzigzag;

import java.time.YearMonth;

public class UserMainCodeThree {

	public static int getLastDayOfMonth(String s) {

		String[] ss=s.split("-");
		
		String part1=ss[0];
		String part2=ss[1];
		String part3=ss[2];
		

		int fPart2=Integer.parseInt(part2);
		int fPart3=Integer.parseInt(part3);
		
		YearMonth ym= YearMonth.of(fPart3,fPart2);
		return ym.lengthOfMonth();
	}

}
