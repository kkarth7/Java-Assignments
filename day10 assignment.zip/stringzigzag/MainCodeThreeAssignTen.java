package com.te.stringzigzag;

import java.util.Scanner;

public class MainCodeThreeAssignTen {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		String s= sc.nextLine();
		int n=UserMainCodeThree.getLastDayOfMonth(s);
		System.out.println(n);
	}

}
