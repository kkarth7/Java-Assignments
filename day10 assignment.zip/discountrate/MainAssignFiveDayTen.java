package com.te.discountrate;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class MainAssignFiveDayTen {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		int size= 4;
	
		Map<String,String> map = new HashMap<String, String>();
		Map<String,String> map1 = new HashMap<String, String>();
		System.out.println("Please enter two account holder's Number and DOR(DD-MM-YYYY)....");
		for (int i = 0; i < size; i++) {
			map.put(sc.nextLine(), sc.nextLine());	
		}
		map1.putAll(map);
		
		Map<String, Integer> map2= new HashMap<String, Integer>();
		System.out.println("Please enter Transaction amount for two account holder's...");
		Iterator<String> itr= map.keySet().iterator();
		while(itr.hasNext())
		{
			String key=itr.next();
			map2.put(key, sc.nextInt());
		}
		Iterator<String> itr1=map2.keySet().iterator();
		while(itr1.hasNext())
		{
			String key2=itr1.next();
			int value=map2.get(key2);	
		}
		
		TreeMap<String, Integer> treeFinal=UserMainCodeFive.calculateDiscount(map,map2);
		
		Iterator<String> itrFinal= treeFinal.keySet().iterator();
		while(itrFinal.hasNext())
		{
			String keyFinalTree= itrFinal.next();
			int valueFinalTree=treeFinal.get(keyFinalTree);
			System.out.println(keyFinalTree+" : "+valueFinalTree);
		}
	}
}
