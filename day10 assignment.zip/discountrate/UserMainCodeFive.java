package com.te.discountrate;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class UserMainCodeFive {

	public static TreeMap<String, Integer> calculateDiscount(Map<String, String> map, Map<String, Integer> map2) {

		Iterator<String> itr= map.keySet().iterator();
		Iterator<String> itr1= map2.keySet().iterator();
		TreeMap<String, Integer> treeMap= new TreeMap<String, Integer>();
		String currentDate="01-01-2015";
		while(itr.hasNext())
		{
			String keyMap=itr.next();
			String valueMap=map.get(keyMap);
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			LocalDate regDate = LocalDate.parse(valueMap,formatter);	
			LocalDate currentFinalDate = LocalDate.parse(currentDate,formatter);	

		    Period period = Period.between(regDate, currentFinalDate);  

			
			while(itr1.hasNext())
			{
				String keyMap2=itr1.next();
				Integer valueMap2=map2.get(keyMap2);
				if(valueMap2>=20000 && period.getYears()>5)
				{
					valueMap2 = (int) (valueMap2*.20);
					treeMap.put(keyMap2, valueMap2);
				}
				else if(valueMap2>=20000 && period.getYears()<5)
				{
					valueMap2 = (int) (valueMap2*.10);
					treeMap.put(keyMap2, valueMap2);
				}
				else if(valueMap2<20000 && period.getYears()>=5)
				{
					valueMap2 = (int) (valueMap2*.15);
					treeMap.put(keyMap2, valueMap2);	
				}
				else if(valueMap2<20000 && period.getYears()<5)
				{
					valueMap2 = (int) (valueMap2*.05);
					treeMap.put(keyMap2, valueMap2);
				}
			}
			
		}
		
		
		return treeMap;
	}

}
