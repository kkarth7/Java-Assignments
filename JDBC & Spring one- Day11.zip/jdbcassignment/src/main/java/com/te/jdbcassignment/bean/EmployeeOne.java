package com.te.jdbcassignment.bean;

import java.sql.Date;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeOne {
private int employeeId;
private String name;
private LocalDate date;
private float salary;

}
