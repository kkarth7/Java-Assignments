package com.te.jdbcassignment.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.te.jdbcassignment.bean.EmployeeOne;

public class DbManagement {

	public boolean addEmployee(EmployeeOne employee)
	{
		boolean result= false;
		Connection con= DBConnectionOne.getConnection();
		String sql="insert into Employee() values(?,?,?,?)";
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, employee.getEmployeeId());
			ps.setString(2, employee.getName());
			ps.setDate(3, java.sql.Date.valueOf(employee.getDate()));
			ps.setFloat(4, employee.getSalary());
			int row= ps.executeUpdate();
			if(row>0)
			{
				result= true;
			}else 
			{
				result=false;
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return result;
		
	}
}

