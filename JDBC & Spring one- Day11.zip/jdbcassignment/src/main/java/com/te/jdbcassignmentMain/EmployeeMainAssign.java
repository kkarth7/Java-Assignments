package com.te.jdbcassignmentMain;

import java.time.LocalDate;
import java.util.Scanner;

import com.te.jdbcassignment.bean.EmployeeOne;
import com.te.jdbcassignment.dao.DbManagement;

public class EmployeeMainAssign {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		System.out.println("enter employee details...");
		EmployeeOne employee= new EmployeeOne(sc.nextInt(),sc.next(),LocalDate.parse(sc.next()),sc.nextFloat());
		DbManagement management = new DbManagement();
		boolean result = management.addEmployee(employee);
		if(result)
		{
			System.out.println("employee details inserted...");
		}
		else
		{
			System.out.println("Data not inserted...");
		}
	}

}
