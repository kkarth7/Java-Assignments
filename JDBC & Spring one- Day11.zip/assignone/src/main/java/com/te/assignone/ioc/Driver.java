package com.te.assignone.ioc;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {
 
	public static void main(String[] args) {
		
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("beanConfigAssign.xml");
		Membership member= (Membership) context.getBean("memberone");
		//Customer cus= (Customer) context.getBean("customer");
		
		System.out.println(member);
	}
}
