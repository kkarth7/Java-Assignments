package assigntwospring;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClassAssignTwo {

	public static void main(String[] args) {

		AbstractApplicationContext context= new ClassPathXmlApplicationContext("beanConfigTwo.xml");
		Passport passport= (Passport) context.getBean("passport");
		Employee employee= (Employee) context.getBean("employee");
		System.out.println(employee);
	}

}
