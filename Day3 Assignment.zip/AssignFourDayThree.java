import java.util.Scanner;

public class AssignFourDayThree {

	public static void main(String[] args) {

		Scanner scn= new Scanner(System.in);
		System.out.println("enter the size of array");
		int n=scn.nextInt();
		int arr[]=new int[n];
		for (int i = 0; i < arr.length; i++) {
			
			arr[i]=scn.nextInt();
			
			}
		double average=UserMainCodeFour.averageElements(arr);
		System.out.println("Average of Prime Index Number is: "+average);
	}

}
