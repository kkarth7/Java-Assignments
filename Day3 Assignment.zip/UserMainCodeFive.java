import java.util.Scanner;

public class UserMainCodeFive {

	public static int sumCommonElements(int size) {
		
		int a[]=new int[size];
		int b[]=new int[size];
		int sum=0;
		Scanner scObj= new Scanner(System.in);
		for (int i = 0; i < a.length; i++) {
			a[i]=scObj.nextInt();
			
		}
		for (int j = 0; j < b.length; j++) {
			b[j]=scObj.nextInt();
		}
		
		for (int i = 0; i < a.length; i++) {
			
			for (int j = 0; j < b.length; j++) {
				
				if(a[i]==b[j])
				{
					sum=sum+a[i];
				}
			}
		}
		
		
		
		return sum;
		
	}

	
}
