import java.util.Scanner;

public class AssignOneDaythree {

	public static void main(String[] args) {

		
		System.out.println("enter the input size of array elements");
		Scanner scObj=new Scanner(System.in);
		int size =scObj.nextInt();
		int sum= UserMainCode.getSumOfPower(size);
		System.out.println("sum of is "+sum);
	}

}
