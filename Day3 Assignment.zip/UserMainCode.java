import java.util.Scanner;

public class UserMainCode {

	public static int getSumOfPower(int size) {	
		int i=0;
		int temp=0, sum=0;
	int []a=new int[size];
		for (i = 0; i < size; i++) 
		{
			Scanner scObj1=new Scanner(System.in);
			a[i] =scObj1.nextInt();
		}
		for (int j = 0; j < a.length; j++) {
			temp= (int) Math.pow(a[j],j);
			
			sum=temp+sum;
		}
		return sum;
	}

}
