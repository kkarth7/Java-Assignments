import java.util.Arrays;
import java.util.Scanner;

public class UserMainCodeTwo {

	public static int getBigDiff(int size) {
	
		int a[]=new int[size];
		int sum1=0, n=a.length,small=0,large=0;
Scanner sObj= new Scanner(System.in);
for (int i = 0; i < a.length; i++) {
	a[i]=(int) sObj.nextInt();
	}

Arrays.sort(a);
for (int i = 0; i < a.length; i++) {

	if(n==1) {
		
		return a[0];
		}
		else {
			   small=a[0];
			   large=n;
			 sum1=large-small;
			}
}
return sum1;
	
	
}

}

