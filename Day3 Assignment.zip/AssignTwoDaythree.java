import java.util.Scanner;

public class AssignTwoDaythree {

	public static void main(String[] args) {

		System.out.println("enter the input size of array elements");
		Scanner scObj=new Scanner(System.in);
		int size =scObj.nextInt();
		int sum= UserMainCodeTwo.getBigDiff(size);
		System.out.println("Sum of Difference between larger and smaller "+sum);
	}

}
