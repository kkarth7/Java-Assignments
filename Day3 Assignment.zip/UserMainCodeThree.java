import java.util.Scanner;

public class UserMainCodeThree {

	public static int checkLargestAmongCorner(int size) {

		int a[]=new int[size],result=0;
		
		int length=a.length; 
		int middleCheck=a.length/2,small=0,Large=0,middle=0;
		Scanner sObj= new Scanner(System.in);
		for (int i = 0; i < a.length; i++) {
			a[i]=sObj.nextInt();
		}
		for (int i = 0; i <length; i++) {
			small=a[0];
			Large=a[length-1];
			middle=a[middleCheck];
		}
			if(small>middle&&small>Large)
			{
				result= small;
			}else if(middle>small&&middle>Large)
			{
				result= middle;
			}else
				result= Large;	
		return result;
	}

}
