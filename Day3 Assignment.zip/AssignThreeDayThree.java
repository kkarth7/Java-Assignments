import java.util.Scanner;

public class AssignThreeDayThree {

	public static void main(String[] args) {

		System.out.println("enter the input size of array elements");
		Scanner scObj=new Scanner(System.in);
		int size =scObj.nextInt();
		int sum= UserMainCodeThree.checkLargestAmongCorner(size);
		System.out.println("Largest number amoung corner"+sum);
	}

}
