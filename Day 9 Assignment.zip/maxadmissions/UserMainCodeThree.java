package com.te.maxadmissions;

import java.util.Iterator;
import java.util.Map;

public class UserMainCodeThree {

	public static int getYear(Map<Integer, Integer> map) {

int temp=0,fkey=0;
Iterator<Integer> itr= map.keySet().iterator();

while(itr.hasNext())
{
	int key=itr.next();
	int value=map.get(key);
	if(value>temp)
	{
		temp=value;
		fkey=key;
	}
}
		return fkey;
	}

}
