package com.te.maxadmissions;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class MainAssignTwoDayNine {

	public static void main(String[] args) {

		System.out.println("Please enter the number of years");
		Scanner sc= new Scanner(System.in);
		int size= sc.nextInt();
		Map<Integer, Integer> map= new HashMap<Integer, Integer>();
		
		for (int i = 0; i < size; i++) {
			
			map.put(sc.nextInt(), sc.nextInt());
		}
	int keyfinal=UserMainCodeThree.getYear(map);
	System.out.println("the Year is.."+keyfinal);
	}
	

}
