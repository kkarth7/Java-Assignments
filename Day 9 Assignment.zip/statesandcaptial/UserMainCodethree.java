package com.te.statesandcaptial;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class UserMainCodethree {

	public static char[] getYear(Map<Integer, Integer> map) {

		int maxValueInMap = (Collections.max(map.values()));
	
System.out.println(maxValueInMap);
	
		return null;
	}
}
