package com.te.statesandcaptial;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.te.largestkeyinhashmap.UserMainCodeOne;

public class MainAssignThreeDayNine {

	public static void main(String[] args) {

		Map<Integer, Integer> map= new HashMap<Integer, Integer>();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the size of the Entry in HashMap");
		int size= sc.nextInt();
		System.out.println("Enter the key and value...");
		for (int i = 0; i < size; i++) {
			map.put(sc.nextInt(), sc.nextInt());	
		}
		System.out.println(map);
		System.out.println(UserMainCodethree.getYear(map));
	}

}
