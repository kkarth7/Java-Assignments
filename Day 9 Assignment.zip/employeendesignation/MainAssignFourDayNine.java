package com.te.employeendesignation;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.te.statesandcaptial.UserMainCodethree;

public class MainAssignFourDayNine {

	public static void main(String[] args) {

		Map<String, String> map= new HashMap<String, String>();
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter the size of the Entry in HashMap");
		int size= sc.nextInt();
		System.out.println("Enter the key (name) and value(Designation)...");
		for (int i = 0; i < size; i++) {
			map.put(sc.next(), sc.next());	
		}
System.out.println("Please enter the input...");
		String s= sc.nextLine();

List list=UserMainCodeFour.obtainDestination(map,s);	

Collections.sort(list);

for (Object o : list) {
	System.out.println(o);
}

		}

}
