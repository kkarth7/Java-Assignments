package com.te.stateidgen;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class MainAssignFiveDayNine {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		int size= sc.nextInt();
		String arr[]= new String[size];
		System.out.println("Please enter the elements..");
		for (int i = 0; i < size; i++) {
			arr[i]=sc.next();
		}
		Map<String, String> map= UserMainCodeFive.getStateId(arr);
		Iterator<String> itr=map.keySet().iterator();
		while(itr.hasNext())
		{
			String 	key=itr.next();
			String value=map.get(key);
			System.out.println(value+" ");
			System.out.println(key);
		}
		
	}

}
