package com.te.largestkeyinhashmap;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MainAssignOneDayNine {

	public static void main(String[] args) {
		
		Map<Integer, String> map= new HashMap<Integer, String>();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the size of the Entry in HashMap");
		int size= sc.nextInt();
		System.out.println("Enter the key and value...");
		for (int i = 0; i < size; i++) {
			map.put(sc.nextInt(), sc.next());	
		}
		System.out.println(map);
		System.out.println(UserMainCodeOne.getMaxKeyValue(map,size));
	}
}
