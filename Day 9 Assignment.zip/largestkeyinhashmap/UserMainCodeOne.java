package com.te.largestkeyinhashmap;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

public class UserMainCodeOne {

	public static String getMaxKeyValue(Map<Integer, String> map,int size) {
		int keyMax[] = new int[size];
		Iterator<Integer> itr=map.keySet().iterator();
		while(itr.hasNext())
		{
			for (int i = 0; i < keyMax.length; i++) {
					keyMax[i]= itr.next();
			}	
		}
		Arrays.sort(keyMax);
		String value= map.get(keyMax[keyMax.length-1]);

		System.out.println(keyMax[keyMax.length-1]);
		
		return value;
	}

}
